module.exports=()=>'stub';
