const fs = require('fs');
console.log('RCE_MARKER_PRIVILEGED_WORKFLOW_RUN');
console.log('TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
console.log('REPO=' + (process.env.GITHUB_REPOSITORY || 'none'));
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');
